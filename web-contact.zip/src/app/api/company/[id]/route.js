import { NextResponse } from "next/server";
import { Company } from "@/models/Company";
import dbConnect from "@/utils/dbConnect";

export async function GET(request, { params }) {
  try {
    await dbConnect();
    const company = await Company.findById(params.id);
    if (!company) {
      return NextResponse.json(
        { success: false, error: "Company not found" },
        { status: 404 }
      );
    }
    return NextResponse.json({ success: true, data: company }, { status: 200 });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: error.message },
      { status: 500 }
    );
  }
}

export async function PUT(request, { params }) {
  try {
    await dbConnect();
    const body = await request.json();
    const company = await Company.findByIdAndUpdate(
      params.id,
      { ...body, updatedAt: Date.now() }, // Ensure updatedAt is set
      { new: true, runValidators: true }
    );
    if (!company) {
      return NextResponse.json(
        { success: false, error: "Company not found" },
        { status: 404 }
      );
    }
    return NextResponse.json({ success: true, data: company }, { status: 200 });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: error.message },
      { status: 400 }
    );
  }
}

export async function DELETE(request, { params }) {
  try {
    await dbConnect();
    const company = await Company.findByIdAndDelete(params.id);
    if (!company) {
      return NextResponse.json(
        { success: false, error: "Company not found" },
        { status: 404 }
      );
    }
    return NextResponse.json(
      { success: true, message: "Company deleted" },
      { status: 200 }
    );
  } catch (error) {
    return NextResponse.json(
      { success: false, error: error.message },
      { status: 500 }
    );
  }
}
