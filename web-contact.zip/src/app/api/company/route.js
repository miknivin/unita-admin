// app/api/companies/route.js
import { NextResponse } from 'next/server';

import { Company } from '@/models/Company';
import dbConnect from '@/utils/dbConnect';

export async function GET() {
  try {
    await dbConnect();
    const companies = await Company.find({});
    return NextResponse.json({ success: true, data: companies }, { status: 200 });
  } catch (error) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    await dbConnect();
    const body = await request.json();
    const company = new Company(body);
    const savedCompany = await company.save();
    return NextResponse.json({ success: true, data: savedCompany }, { status: 201 });
  } catch (error) {
    return NextResponse.json({ success: false, error: error.message }, { status: 400 });
  }
}